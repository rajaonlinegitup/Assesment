﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mathematics
{
      public class Test
    {
        public static void FindStatus(string x)
        {
            if (int.TryParse(x, out int value))
            {
                int xx = Convert.ToInt32(x);

                if (xx % 3 == 0 && xx % 5 == 0)
                {
                    Console.WriteLine("Given Input Number {0} is FizzBuzz", xx);
                }
                else if (xx % 3 == 0)
                {
                    Console.WriteLine("Given Input Number {0} is Fizz", xx);
                }
                else if (xx % 5 == 0)
                {
                    Console.WriteLine("Given Input Number {0} is Buzz", xx);
                }
                else
                {
                    Console.WriteLine("Given Input Number {0} is not met anything", xx.ToString());
                }
                Console.WriteLine("For Next : Press Enter \n");
            }

            else
                Console.WriteLine("Given Input is not a Number: {0} ", x);


        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            FindMod obj = new FindMod();

            for (int x = 0; x < 10; x++)
            {
                Console.WriteLine(obj.FindCalculation(x));
            }
            Console.ReadLine();
        }
    }

        
    }
  

