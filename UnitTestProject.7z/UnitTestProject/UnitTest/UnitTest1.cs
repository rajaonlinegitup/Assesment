﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Mathematics;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

            Test.FindStatus("3");
        }

        [TestMethod]
        public void TestMethod2()
        {
            Test.FindStatus("4");
        }

        [TestMethod]
        public void TestMethod3()
        {
           Test.FindStatus("5");
        }


        [TestMethod]
        public void TestMethod4()
        {
            Test.FindStatus("a");
        }
    }
}
